package bgu.spl.net.api.bidi;

import java.io.Serializable;

public class LogoutMsg extends Message {


    public LogoutMsg (){
        super((short )3);
    }
}
